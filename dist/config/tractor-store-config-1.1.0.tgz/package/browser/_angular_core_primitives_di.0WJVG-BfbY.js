import { a as r, b as t, c as o, d as u, e as d, f as i } from "@nf-internal/chunk-NBAXJWZT";
import "@nf-internal/chunk-4CLCTAJ7";
function c(e) { return { token: e.token, providedIn: e.providedIn || null, factory: e.factory, value: void 0 }; }
function f(e, n) { return e.ɵprov = n, e; }
export { u as NOT_FOUND, d as NotFoundError, c as defineInjectable, r as getCurrentInjector, o as inject, i as isNotFound, f as registerInjectable, t as setCurrentInjector }; /*! Bundled license information:

@angular/core/fesm2022/primitives/di.mjs:
  (**
   * @license Angular v20.1.7
   * (c) 2010-2025 Google LLC. https://angular.io/
   * License: MIT
   *)
*/
