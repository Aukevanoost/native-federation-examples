import{b as a}from"./chunk-SICEOHVC.js";export{a as AppComponent};
